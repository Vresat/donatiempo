<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="w-full md:w-2/3 flex flex-col items-stretch px-3">
        <article class="flex flex-col shadow my-4">
            <a href="" class="hover:opacity-75">
                <img src="<?php echo e($ad->image); ?>">
            </a>
            <div class="bg-white flex flex-col justify-start p-6">
                <a href="<?php echo e(route('by-category',$ad)); ?>" class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($ad->category->name); ?></a>
                <p class="text-3xl font-bold hover:text-gray-700 pb-4"><?php echo e($ad->name); ?></p>
                <p class="text-sm pb-8">
                    Por <strong class="font-semibold hover:text-gray-800"><?php echo e($ad->user->name); ?></strong>, Publicado el <?php echo e($ad->getFormattedDate()); ?>

                </p>
                <p class="pb-3 py-2"><?php echo e($ad->body); ?></p>
            </div>
            <?php if(auth()->guard()->check()): ?>
            <?php if($senderNotification!=NULL): ?>
            <?php echo $__env->make('user.ad.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
            <?php echo $__env->make('user.ad.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <?php endif; ?>
        </article>
        <div class="w-full flex pt-6">
            <div class="w-1/2">
                <?php if($prev): ?>
                <a href="<?php echo e(route('view',$prev)); ?>" class="w-1/2 bg-white shadow hover:shadow-md text-left">
                    <p class="text-lg text-blue-800 font-bold flex items-center"><i class="fas fa-arrow-left pr-1"></i> Anterior</p>
                    <p class="pt-2"><?php echo e($prev->name); ?></p>
                </a>
                <?php endif; ?>
            </div>
            <div class="w-1/2">
                <?php if($next): ?>
                <a href="<?php echo e(route('view',$next)); ?>" class="w-1/2 bg-white shadow hover:shadow-md text-right">
                    <p class="text-lg text-blue-800 font-bold flex items-center justify-end">Siguiente <i class="fas fa-arrow-right pl-1"></i></p>
                    <p class="pt-2"><?php echo e($next->name); ?></p>
                </a>
                <?php endif; ?>
            </div>
        </div>

        <div class="w-full flex flex-col text-center md:text-left md:flex-row shadow bg-white mt-10 mb-10 p-6">
            <div class="w-full md:w-1/5 flex justify-center md:justify-start pb-4">
                <img src="<?php echo e($ad->user->avatar); ?>" class="object-cover mx-1 rounded-full shadow h-20 w-20 ">
            </div>
            <div class="flex-1 flex flex-col justify-center md:justify-start">
                <p class="font-semibold text-2xl"><?php echo e($ad->user->name); ?></p>

                <?php if(!$ad->user->comments()->isEmpty()): ?>
                <div x-data="{rating:'<?php echo e($ad->user->rating()); ?>' }" class="pt-2">
                    <ul class="flex justify-left">
                        <template x-for="i in 5">
                            <li>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" x-bind:fill="(i<=rating) ? 'yellow' : 'none'" x-bind:stroke="(i>=rating) ? 'yellow' : 'none'" class="mr-1 h-5 w-5 text-warning">
                                    <path fill-rule="evenodd" d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z" clip-rule="evenodd" />
                                </svg>
                            </li>
                        </template>
                    </ul>
                </div>
                <p class="pt-1">Ultimos comentarios</p>
                
                <div class="flex flex-row justify-start">
                <?php $__currentLoopData = $ad->user->comments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="w-1/2">
                        <div class="m-4 block rounded-lg bg-white p-6 shadow-lg dark:bg-neutral-800 dark:shadow-black/20">
                            <div class="md:flex md:flex-row">
                                <div class="mx-auto mb-6 flex w-16 items-center justify-center md:mx-0 md:w-16 lg:mb-0">
                                    <img src="<?php echo e($ad->user->userComment($comment)->avatar); ?>" class="rounded-full shadow-md dark:shadow-black/30" alt="avatar" />
                                </div>
                                <div class="md:ml-6">
                                    <p class="mb-6 font-light text-neutral-500 dark:text-neutral-300">
                                        <?php echo e($comment->body); ?>

                                    </p>
                                    <p class="mb-2 text-xl font-semibold text-neutral-800 dark:text-neutral-200">
                                        <?php echo e($ad->user->userComment($comment)->name); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="flex items-center justify-center md:justify-start text-2xl no-underline text-blue-800 pt-4">
                    <?php if($ad->user->facebook!=NULL): ?>
                    <a class="" href="$ad->user->facebook">
                        <i class="fab fa-facebook"></i>
                    </a>
                    <?php endif; ?>
                    <?php if($ad->user->instagram!=NULL): ?>
                    <a class="pl-4" href="$ad->user->instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <?php endif; ?>
                    <?php if($ad->user->twitter!=NULL): ?>
                    <a class="pl-4" href="$ad->user->twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <?php endif; ?>
                    <?php if($ad->user->linkedin!=NULL): ?>
                    <a class="pl-4" href="$ad->user->linkedin">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/user/ad/view.blade.php ENDPATH**/ ?>