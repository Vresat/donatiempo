
<?php $__env->startSection('body'); ?>

<article class="w-full flex flex-col shadow my-4">
    <div class=" bg-white flex flex-col justify-start p-6">
        <p class="text-blue-700 text-sm font-bold uppercase pb-4">Nombre de usuario que hace el comentario</p>
        <p class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($comment->commentsDo->name); ?></p>
        <p class="font-bold pb-4">Email: <?php echo e($comment->commentsDo->email); ?></p>
        <p class="pb-3 py-2">Comentario:</p>
        <p class="text-blue-700 text-sm font-bold pb-3 py-2"><?php echo e($comment->body); ?></p>
        <p class="pb-3 py-2">Rating realizado sobre <?php echo e($comment->commentsReceive->name); ?>:</p>
        <p class="text-blue-700 text-sm font-bold pb-3 py-2 ml-20"><?php echo e($comment->rating); ?></p>
        
        
        <?php if($comment->active): ?>
        <a href="<?php echo e(route('adminCommentEdit',$comment)); ?>" class="w-full font-bold text-sm uppercase rounded bg-white text-orange-700 hover:bg-orange-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Desactivar</a>
        <?php else: ?>
        <a href="<?php echo e(route('adminCommentEdit',$comment)); ?>" class="w-full font-bold text-sm uppercase rounded bg-white text-green-700 hover:bg-green-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Activar</a>
        <?php endif; ?>
        <a href="<?php echo e(route('adminIndex')); ?>" class="w-full font-bold text-sm uppercase rounded text-blue-700 hover:bg-blue-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Volver</a>
    </div>
</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/admin/commentsShow.blade.php ENDPATH**/ ?>