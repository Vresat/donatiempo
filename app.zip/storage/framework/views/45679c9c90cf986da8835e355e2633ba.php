
<div class="container mx-auto shadow-lg rounded-lg">
    <div class="px-5 py-5 flex justify-between items-center bg-white border-b-2">
        <h3 class="font-bold text-blue-700">Mensajes</h3>
    </div>
    <?php if(!is_null($messageAds)): ?>
        <?php if(Auth::user()->id == $ad->user_id): ?>
    <div class="w-full px-5 flex flex-col justify-between">
        <?php $__currentLoopData = $messageAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messageAd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div x-data="{ open: false }">
        
            <img src="<?php echo e(App\Models\User::find($messageAd[0]->sender_id)->avatar); ?>" class="object-cover mx-1 rounded-full shadow h-8 w-8 mt-2">
            
            <button @click="open = ! open" class="rounded-[10px] p-2 mt-2 mb-1 text-blue-800 border-4 border-blue-800 font-extrabold "><?php echo e(App\Models\User::find($messageAd[0]->sender_id)->name); ?></button>
            <div x-show="open" @click.outside="open = false" class="flex flex-col mt-5">
                <?php $__currentLoopData = $messageAd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex <?php echo e($messages->sender_id==Auth::user()->id ? 'justify-end':'justify-start'); ?> mb-4">
                    <div class="mr-2 py-3 px-4 <?php echo e($messages->sender_id==Auth::user()->id ? 'bg-blue-400' : 'bg-gray-400'); ?> rounded-bl-3xl rounded-tl-3xl rounded-tr-xl text-white">
                        <?php echo e($messages->body); ?>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(Auth::check()): ?>
                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-form','data' => ['ad' => $ad,'messageAd' => $messageAd]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad),'messageAd' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($messageAd)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        <?php else: ?>
    <div class="w-full px-5 flex flex-col justify-between">
        <div class="flex flex-col mt-5">
            <?php $__currentLoopData = $messageAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex <?php echo e($messages->sender_id==Auth::user()->id ? 'justify-end':'justify-start'); ?> mb-4">
                <div class="mr-2 py-3 px-4 <?php echo e($messages->sender_id==Auth::user()->id ? 'bg-blue-400' : 'bg-gray-400'); ?> rounded-bl-3xl rounded-tl-3xl rounded-tr-xl text-white">
                    <?php echo e($messages->body); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <?php if(Auth::check()): ?>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-form','data' => ['ad' => $ad]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <?php if((Auth::check()) && (auth()->user()->id != $ad->user_id)): ?>
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.chat-form','data' => ['ad' => $ad]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('chat-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['ad' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($ad)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <?php endif; ?>
        <?php endif; ?>
    
</div><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/user/ad/messages.blade.php ENDPATH**/ ?>