<p class="text-lg text-blue-950">Politica de privacidad</p>
<p class="font-bold-3xl">Regulaciones legales a las que se acoge esta web</p>
<p>Dona Tiempo está adecuada a las exigencias de la ley Orgánica 3/2018, de 5 de diciembre, de Protección de Datos Personales</p>
<p>y garantía de los derechos dígitales. Cumple tambien con el Reglamento(UE)2016/679 del Parlamento Europeo y del Consejo de</p>
<p>de abril de 2016 relativo a la protección de las personas físicas (RGPD),así como con la ley 34/2002, de 11 de julio, de</p>
<p>Servicios de la Sociedad de la información y Comercio Electrónico (LSSICE o LSSI).
<p class="font-bold-3xl">Máxima transparencia con los usuarios</p>
<p>La transparencia es el pilar fundamental de la privacidad. A efectos de lo previsto en:</p>
<ul>
    <li>El Reglamento (UE)2016/679 del Parlamento Europeo y del consejo de 27 de abril de 2016 relatívo a la protección de las personas fisicas en lo que respecta al tratamiento de datos personales y a la libre circulación de estos datos y por el que se deroga la Directiva 95/46/CE (Reglamento general de protección de datos).</li>
    <li>La ley Orgánica de Protección de Datos Personales y Garantía de los Derechos Digitales(LOPDGDD)3/2018 adapta el derecho español al modelo establecido por el Reglamento General de Protección de Datos (RGPD).</li>
    <li>La Ley 34/2002 de 21 de julio, de Servicios de la Sociedad de la información y Comercio Electrónico(LSSICE ó LSSI).Regula las transacciones económicas mediante medios electrónicos.</li>
</ul>
<ul>
    <li>Titular: Vicente Antón Serrano</li>
    <li>N.I.F: 74323232F</li>
    <li>Domicilio:Calle Fernanda SantaMaria 67, 1 03204 Elche(Alicante)</li>
    <li>Email:admin@donatiempo.es</li>
</ul><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/components/privacidad.blade.php ENDPATH**/ ?>