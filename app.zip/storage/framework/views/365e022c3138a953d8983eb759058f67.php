
<?php $__env->startSection('body'); ?>

<article class="w-full flex flex-col shadow my-4">
    <!-- Article Image -->
    <a href="" class="hover:opacity-75">
        <img src="<?php echo e($ad->image); ?>">
    </a>
    <div class=" bg-white flex flex-col justify-start p-6">
        <a href="#" class="text-blue-700 text-sm font-bold uppercase pb-4"><?php echo e($ad->category->name); ?></a>
        <a href="#" class="text-3xl font-bold hover:text-gray-700 pb-4"><?php echo e($ad->name); ?></a>
        <p href="#" class="text-sm pb-8">
            By <a href="#" class="font-semibold hover:text-gray-800"><?php echo e($ad->user->name); ?></a>, Publicado el <?php echo e($ad->getFormattedDate()); ?>

        </p>
        <p class="pb-3 py-2"><?php echo e($ad->body); ?></p>
        <a href="<?php echo e(route('adminIndex')); ?>" class="w-full font-bold text-sm uppercase rounded text-blue-700 hover:bg-blue-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Volver</a>
        <?php if($ad->active): ?>
        <a href="<?php echo e(route('adminActDes',$ad)); ?>" class="w-full font-bold text-sm uppercase rounded bg-white text-orange-700 hover:bg-orange-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Desactivar</a>
        <?php else: ?>
        <a href="<?php echo e(route('adminActDes',$ad)); ?>" class="w-full font-bold text-sm uppercase rounded bg-white text-green-700 hover:bg-green-700 hover:text-white flex items-center justify-center px-2 py-3 mt-4">Activar</a>
        <?php endif; ?>
    </div>
    
</article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/ad/show.blade.php ENDPATH**/ ?>