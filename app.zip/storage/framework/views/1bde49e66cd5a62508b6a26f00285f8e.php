

<?php $__env->startSection('body'); ?>
<div class="mt-8">
    <div class="mt-4">
        <div class="p-6 bg-white rounded-md shadow-md">
            <h2 class="text-lg text-gray-700 font-semibold capitalize">Editar Usuario</h2>

            <form action="<?php echo e(route('adminStoreUser')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="grid grid-cols-1 sm:grid-cols-1 gap-6 mt-4">
                    <div>
                        <label class="text-gray-700" for="ciudad">Nombre</label>
                        <input class="form-input w-full mt-2 rounded-md focus:border-indigo-600" type="text" name="name" value="<?php echo e($user->name); ?>">
                    </div>
                    <div>
                        <label class="text-gray-700" for="nombre">Email</label>
                        <input class="form-input w-full mt-2 rounded-md focus:border-indigo-600" type="email" name="email" value="<?php echo e($user->email); ?>">
                    </div>

                    <div>
                        <label class="text-gray-700" for="anuncio">Estado</label>
                        <select class="form-input w-full mt-2 rounded-md focus:border-indigo-600" name="activo">
                            <option value='true'>Activar</option>
                            <option value='false'>Desactivar</option>
                        </select>
                        <div class="flex justify-end mt-4">
                            <button class="px-4 py-2 bg-gray-800 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">Guardar</button>
                        </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/form.blade.php ENDPATH**/ ?>