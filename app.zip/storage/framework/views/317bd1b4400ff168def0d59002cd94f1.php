

<?php $__env->startSection('body'); ?>
    <h3 class="text-gray-700 text-3xl font-medium">Contacto</h3>
    <div class="flex flex-col mt-8">
        <div class="-my-2 py-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
            <div class="align-middle inline-block min-w-full shadow overflow-hidden sm:rounded-lg border-b border-gray-200">
                <p class="px-2">Nombre: <?php echo e($notification->data['name']); ?></p>
                <p class="px-2">Email: <?php echo e($notification->data['email']); ?></p>
                <p class="px-2">Asunto: <?php echo e($notification->data['asunto']); ?></p>
                <p class="px-2">Solicitud: <?php echo e($notification->data['help']); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin._layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/admin/contact.blade.php ENDPATH**/ ?>