
<div class="py-5">
            <form action="<?php echo e(route('sendMessage',$ad)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="w-full bg-gray-300 py-5 px-3 rounded-xl" type="text" name="body" placeholder="Escribe tu mensaje aqui..." />
                <input type="hidden" name="adresser" value="<?php echo e(isset($messageAd) ? $messageAd['0']->sender_id : (isset($senderNotification) ? $senderNotification : $ad->user_id)); ?>" />
                <div x-data={submit:true} class="flex justify-end mt-4">
                    <button @click="submit=false" :class="submit ? '' : 'hidden'" class="px-4 py-2 bg-blue-400 text-gray-200 rounded-md hover:bg-indigo-500 focus:outline-none focus:bg-gray-700">Enviar</button>
                </div>
            </form>
</div>
<?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/components/chat-form.blade.php ENDPATH**/ ?>