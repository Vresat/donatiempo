<!-- This is an example component -->
<div class="container mx-auto shadow-lg rounded-lg">
    <!-- headaer -->
    <div class="px-5 py-5 flex justify-between items-center bg-white border-b-2">
        Mensaje
    </div>
    <?php if(!is_null($messageAds)): ?>
    <?php if(Auth::user()->id == $ad->user_id): ?>
    <div class="w-full px-5 flex flex-col justify-between">
    <?php $__currentLoopData = $messageAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex <?php echo e($messages->sender_id==Auth::user()->id ? 'justify-end':'justify-start'); ?> mb-4">
                    <div class="mr-2 py-3 px-4 <?php echo e($messages->sender_id==Auth::user()->id ? 'bg-blue-400' : 'bg-gray-400'); ?> rounded-bl-3xl rounded-tl-3xl rounded-tr-xl text-white">
                        <?php echo e($messages->body); ?>

                    </div>
                    <img src="https://source.unsplash.com/vpOeXr5wmR4/600x600" class="object-cover h-8 w-8 rounded-full" alt="" />
                </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
            <?php if(Auth::check()): ?>
                <div class="py-5">
                    <form action="<?php echo e(route('sendMessage',$ad)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input class="w-full bg-gray-300 py-5 px-3 rounded-xl" type="text" name="body" placeholder="type your message here..." />
                        <input type="hidden" name="adresser" value="<?php echo e($messageAds['0']->sender_id); ?>" />
                        <div class="flex justify-end mt-4">
                            <button class="px-4 py-2 bg-gray-800 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">Enviar</button>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
    <div class="w-full px-5 flex flex-col justify-between">
        <?php $__currentLoopData = $messageAds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col mt-5">
            <div class="flex <?php echo e($messages->sender_id==Auth::user()->id ? 'justify-end':'justify-start'); ?> mb-4">
                <div class="mr-2 py-3 px-4 <?php echo e($messages->sender_id==Auth::user()->id ? 'bg-blue-400' : 'bg-gray-400'); ?> rounded-bl-3xl rounded-tl-3xl rounded-tr-xl text-white">
                    <?php echo e($messages->body); ?>

                </div>
                <img src="https://source.unsplash.com/vpOeXr5wmR4/600x600" class="object-cover h-8 w-8 rounded-full" alt="" />
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(Auth::check()): ?>
        <div class="py-5">
            <form action="<?php echo e(route('sendMessage',$ad)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="w-full bg-gray-300 py-5 px-3 rounded-xl" type="text" name="body" placeholder="type your message here..." />
                <input type="hidden" name="adresser" value="<?php echo e($ad->user_id); ?>" />
                <div class="flex justify-end mt-4">
                    <button class="px-4 py-2 bg-gray-800 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">Enviar</button>
                </div>
            </form>
        </div>
        <?php endif; ?>
        <?php endif; ?>
        <?php else: ?>
        <?php if(Auth::check()): ?>
        <div class="py-5">
            <form action="<?php echo e(route('sendMessage',$ad)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input class="w-full bg-gray-300 py-5 px-3 rounded-xl" type="text" name="body" placeholder="type your message here..." />
                <input type="hidden" name="adresser" value="<?php echo e($ad->user_id); ?>" />
                <div class="flex justify-end mt-4">
                    <button class="px-4 py-2 bg-gray-800 text-gray-200 rounded-md hover:bg-gray-700 focus:outline-none focus:bg-gray-700">Enviar</button>
                </div>
            </form>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<!-- end message -->
</div><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/ad/message.blade.php ENDPATH**/ ?>