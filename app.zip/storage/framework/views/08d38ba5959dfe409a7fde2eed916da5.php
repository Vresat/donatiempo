<header class="flex items-center justify-between px-6 py-4 bg-white border-b-4 border-indigo-600">

    <?php if(session('status')): ?>
    <div x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 2000)" class="w-full pl-3 py-1 bg-green-200 text-white">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>
    <div class="flex items-center">
        <button @click="sidebarOpen = true" class="text-gray-500 focus:outline-none lg:hidden">
            <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M4 6H20M4 12H20M4 18H11" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
            </svg>
        </button>
    </div>
    <div class="flex items-center">
        <a href="<?php echo e(route('home')); ?>" class="flex items-center px-2 py-2 -mx-2 text-gray-600 hover:text-white hover:bg-indigo-600 rounded-md">
            <svg height="32" viewBox="0 0 48 48" width="48" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
                <path d="M20 40V28h8v12h10V24h6L24 6 4 24h6v16z" stroke="currentColor" />
                <path d="M0 0h48v48H0z" fill="none" />
            </svg>
            Aplicación
        </a>
    </div>
    <?php if(auth()->user()->unreadNotifications->count()!=0): ?>
    <div class="flex items-end">
        <div x-data="{ notificationOpen: false}" class="relative">
            <button @click="notificationOpen = ! notificationOpen" class="flex mx-4 text-gray-600 focus:outline-none">
                <svg class="w-6 h-6" viewBox="0 0 24 24" fill="rgb(29,78,216)" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 17H20L18.5951 15.5951C18.2141 15.2141 18 14.6973 18 14.1585V11C18 8.38757 16.3304 6.16509 14 5.34142V5C14 3.89543 13.1046 3 12 3C10.8954 3 10 3.89543 10 5V5.34142C7.66962 6.16509 6 8.38757 6 11V14.1585C6 14.6973 5.78595 15.2141 5.40493 15.5951L4 17H9M15 17V18C15 19.6569 13.6569 21 12 21C10.3431 21 9 19.6569 9 18V17M15 17H9" stroke="rgb(29,78,216)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
                <span class="bg-blue-700 text-white font-bold rounded-full pl-1 pr-1"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
            </button>

            <div x-cloak x-show="notificationOpen" @click="notificationOpen = false" class="fixed inset-0 z-10 w-full h-full"></div>

            <div x-cloak x-show="notificationOpen" class="absolute right-0 z-10 mt-2 overflow-hidden bg-white rounded-lg shadow-xl w-80" style="width:20rem;">
                <?php $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(str_contains($notification->type,'NewUserNotification')): ?>
                <a href="<?php echo e(route('adminEditUser',$notification->data['id'])); ?>" class="flex items-center px-4 py-3 -mx-2 text-gray-600 hover:text-white hover:bg-indigo-600">
                    <p class="mx-2 text-sm">
                        <span class="font-bold pr-1"><?php echo e($notification->data['name']); ?></span>ha sido activado el <span class="font-bold text-indigo-400 pr-1 pl-1"><?php echo e($notification->data['created_at']); ?></span>
                    </p>
                </a>
                <?php elseif(str_contains($notification->type,'NewAdNotification')): ?>
                <a href="<?php echo e(route('adminShow',$notification->data['ad_id'])); ?>" class="flex items-center px-4 py-3 -mx-2 text-gray-600 hover:text-white hover:bg-indigo-600">
                    <img class="object-cover w-8 h-8 mx-1 rounded-full" src="<?php echo e($notification->data['name']['avatar']); ?>" alt="avatar">
                    <p class="mx-2 text-sm">
                        <span class="font-bold pr-1">el anuncio <?php echo e($notification->data['ad_name']); ?></span>ha sido creado por <span class="font-bold text-indigo-400 pr-1 pl-1"><?php echo e($notification->data['name']['name']); ?></span><?php echo e($notification->data['created_at']); ?>

                    </p>
                </a>
                <?php elseif(str_contains($notification->type,'ContactNotification')): ?>
                <a href="<?php echo e(route('adminContact',$notification)); ?>" class="flex items-center px-4 py-3 -mx-2 text-gray-600 hover:text-white hover:bg-indigo-600">
                    <p class="mx-2 text-sm">
                        <span class="font-bold pr-1">Tiene un nuevo mensaje de contacto de <?php echo e($notification->data['name']); ?></span>
                    </p>
                </a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div x-data="{ dropdownOpen: false }" class="relative">
        <button @click="dropdownOpen = ! dropdownOpen" class="relative block w-8 h-8 overflow-hidden rounded-full shadow focus:outline-none">
            <img class="object-cover w-full h-full" src="<?php echo e(auth()->user()->avatar); ?>" alt="avatar">
        </button>

        <div x-cloak x-show="dropdownOpen" @click="dropdownOpen = false" class="fixed inset-0 z-10 w-full h-full"></div>

        <div x-cloak x-show="dropdownOpen" class="absolute right-0 z-10 w-48 mt-2 overflow-hidden bg-white rounded-md shadow-xl">
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>

                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                    <?php echo e(__('Log Out')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </form>
        </div>
    </div>
</header><?php /**PATH C:\xampp\htdocs\donatiempo\resources\views/admin/_layouts/header.blade.php ENDPATH**/ ?>