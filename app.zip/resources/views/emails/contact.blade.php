<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Correo Electronico</h1>
    <p>Correo de contacto</p>
    <p>Nombre: {{$contact['name']}}</p>
    <p>Asunto: {{$contact['asunto']}}</p>
    <p>Mensaje: {{$contact['body']}}</p>
</body>
</html>