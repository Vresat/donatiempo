<x-app-layout>
        <div class="w-full lg:w-2/3 md:w-2/3 flex flex-col items-center px-3 mt-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
            {{ $slot }}
        </div>
</x-app-layout>